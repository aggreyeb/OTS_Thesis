/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.ObjectModels;

/**
 *
 * @author MEA
 */
public class TestGenerationInput {
    public int KnowledgeMapId;
    public String NodeParent;
    public String NodeIdentity;
    public int CourseId;
    public int TestId;
    public Boolean IncludeSubTrees; 
    public int CognitiveType;
    public int ItemType;
    public int NatureOfItem;
    public  String UniqueId;
    public Boolean InvalidOutput=false;
    public String InvalidOutputText="";
}
