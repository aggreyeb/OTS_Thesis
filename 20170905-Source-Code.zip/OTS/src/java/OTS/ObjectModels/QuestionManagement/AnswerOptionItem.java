/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.ObjectModels.QuestionManagement;

/**
 *
 * @author MEA
 */
public class AnswerOptionItem {
    public int AnswerOptionId;
    public String AnswerOptionText;
    public String AnswerOptionValue;
    public String LabelText;
    public String UniqueId;
    public Boolean IsCorrect;
    public String IsChecked;
    public String CheckedText;
    public String CheckedStyle="";
}
