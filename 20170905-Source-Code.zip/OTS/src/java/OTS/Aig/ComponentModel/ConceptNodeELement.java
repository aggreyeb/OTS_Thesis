/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.Aig.ComponentModel;

/**
 *
 * @author MEA
 */
public class ConceptNodeELement {
     String ConceptNodeId;
     String ConceptNodeName;
     String ParentId;
     String ParentName;
     String RelationTypeName;
     String RootId;
     String RootName;
}
