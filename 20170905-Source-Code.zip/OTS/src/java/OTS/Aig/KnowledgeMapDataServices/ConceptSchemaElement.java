/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.Aig.KnowledgeMapDataServices;

/**
 *
 * @author Eb
 */
public class ConceptSchemaElement {
   public String RootId;//KnowledgeMapId
   public String ParentId;
   public String ConceptSchemaId;
   public  String ConceptNodeId;
   public String RelationName;
   public String ConceptName;
   public String ActionName;
   public String AttributeName;
   public String AttributeValue;
}
