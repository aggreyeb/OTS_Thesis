var Aig=Aig||{};



Aig.Device=function(){
    var me=this;
    
    
    me.ReadSettings=function(){
       var settings= {
           id:""
       };
       return settings;
    };
};


