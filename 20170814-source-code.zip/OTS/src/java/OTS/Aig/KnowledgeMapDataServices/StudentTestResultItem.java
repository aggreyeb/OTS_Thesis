/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.Aig.KnowledgeMapDataServices;

/**
 *
 * @author MEA
 */
public class StudentTestResultItem {
   
    public String TestId;
    public String TestName;
    public String CourseId;
    public String CourseName;
    public String StartDateTime;
    public String EndDataTime;
    public Boolean Taken;
    public Boolean Marked;
    public int Mark;
}
