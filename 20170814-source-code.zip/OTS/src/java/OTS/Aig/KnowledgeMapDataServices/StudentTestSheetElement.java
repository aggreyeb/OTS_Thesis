/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.Aig.KnowledgeMapDataServices;

import java.util.Date;

/**
 *
 * @author MEA
 */
public class StudentTestSheetElement {
   public  String Id;
   public String Name;
   public String TestId;
   public  int StudentId;
   public  String TestSheet;
   public  Date StartDateTime;
   public   Date EndDateTime;
   public  int Marked;
   public  int Taken;
   public  int Mark;
   public int TestItemCount;
   public  String Comments;
}
