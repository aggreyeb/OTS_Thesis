/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.ObjectModels;

import java.util.Date;

/**
 *
 * @author MEA
 */
public class KnowledgeMapItem {
    public int KnowledgeMapId;
    public String Name;
    public String Description;
    public Date CreatedOn;
    public boolean IsPublic;
    public String FirstName;
    public String LastName;
    public String CreatedBy;
}


