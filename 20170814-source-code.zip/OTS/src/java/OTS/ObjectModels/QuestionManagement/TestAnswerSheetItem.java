/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.ObjectModels.QuestionManagement;

/**
 *
 * @author Eb
 */
public class TestAnswerSheetItem {
    public int TestAnswerSheetId;
    public int TestId;
    public int TestItemId;
    public Boolean A;
    public Boolean B;
    public Boolean C;
    public Boolean D;
    public int LineNumber;
}
