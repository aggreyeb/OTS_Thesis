/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.ObjectModels.QuestionManagement;

/**
 *
 * @author Eb
 */
public class TestMarkingAnswerSheet {
         public int  AnswerSheetId;
         public int TestItemId ;
         public int QuestionType;
         public int CognitiveLevelTypeId;
         public int QuestionNatureType;
         public Boolean A;
         public Boolean B;
         public Boolean C;
         public Boolean D;
         public float Mark;
         public Boolean IsCorrect;
         public  int TotalCorrectAnswers;
}
