/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.ObjectModels.QuestionManagement;

import java.util.Date;

/**
 *
 * @author Eb
 */
public class TestHistoryItem {
    public int StudentTestHistoryId;
    public int StudentId;
    public int TestId;
    public Date StartDate;
    public Date EndDate;
    public float TotalMark;
}
