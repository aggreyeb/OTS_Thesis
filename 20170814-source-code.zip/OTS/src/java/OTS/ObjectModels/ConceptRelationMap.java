/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.ObjectModels;

/**
 *
 * @author aggreeb
 */
public class ConceptRelationMap {
    public String PartOfMap;
    public String TypeOfMap;

    public ConceptRelationMap(String PartOfMap, String TypeOfMap) {
        this.PartOfMap = PartOfMap;
        this.TypeOfMap = TypeOfMap;
    }
    
    
}
