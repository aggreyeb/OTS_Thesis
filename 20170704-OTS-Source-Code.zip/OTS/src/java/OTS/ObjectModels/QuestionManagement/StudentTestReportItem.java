/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.ObjectModels.QuestionManagement;

import java.util.Date;

/**
 *
 * @author Eb
 */
public class StudentTestReportItem {
   public int UserId;
   public String Name;
   public Date StartDate;
   public Date EndDate;
   public String TimeSpent="";
   public String Marked="No";
   public float TotalMark;
}
