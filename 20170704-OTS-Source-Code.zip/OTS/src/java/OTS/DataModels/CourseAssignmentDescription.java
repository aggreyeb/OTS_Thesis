/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package OTS.DataModels;

/**
 *
 * @author MEA
 */
public class CourseAssignmentDescription {
  public  int Id;
  public String Number;
  public String Name;
  public String Description;

}
