/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.Aig.KnowledgeMapDataServices;

import java.util.Date;

/**
 *
 * @author MEA
 */
public class TestElement {
   public String Id;
   public String Name;
   public  int TotalMark;    
   public String StartDate;
   public String StartTime="";
   public String EndTime="";
   public int  Activated;
   public String CourseId;
   public String CourseName;
   public String TestQuestions;
   public String TestSheet;
   public String AnswerSheet;
           
}
