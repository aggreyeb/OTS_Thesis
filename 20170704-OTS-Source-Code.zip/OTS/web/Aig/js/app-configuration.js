﻿var Aig = Aig || {};
Aig.Configurations = Aig.Configurations || {};

Aig.Configurations.AppConfiguration = function() {
    var me = this;
};