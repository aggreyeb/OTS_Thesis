
var OTS=OTS||{};
OTS.Pages.UserAccountPage=function(){
   
    
};
OTS.Pages.UserAccountPage.prototype = new OTS.Pages.BasePage();
OTS.Pages.UserAccountPage.prototype.constructor = OTS.Pages.BasePage;