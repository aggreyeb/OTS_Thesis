/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.Aig.KnowledgeMapDataServices;

/**
 *
 * @author MEA
 */
public class StudentTest {
   public int StudentId;
   public String Id;
   public String Name;
   public  int Mark;    
   public int  Activated;
   public String TestQuestions;
   public String TestSheet;
   public String AnswerSheet;
   public String Score="";
   public int Taken;
   public int Marked;
   public String TakenText="No";
   public String MarkedText="No";
   public int TestItemCount;  
}
