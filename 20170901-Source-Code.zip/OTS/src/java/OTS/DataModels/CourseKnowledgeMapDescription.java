/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package OTS.DataModels;

/**
 *
 * @author MEA
 */
public class CourseKnowledgeMapDescription {
    
    public int CourseTypeId;
    public int KnowledgeMapId;
    public String Name;
    public String Description;
    public String ActionText;
    public Boolean CanEnableSelect;
}
