/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.ObjectModels;

/**
 *
 * @author MEA
 */
public class QuestionBankItem {
   
    public int QuestionBankId;
    public String QuestionText;
    public String GroupId;
    public int CognitiveLevelTypeId;
    public int QuestionNatureTypeId;
    public int QuestionTypeId;
    public int TestId;
    public String CognitiveTypeName;
    public String QuestionNatureTypeName;
    public String QuestionTypeName;
    
}
