/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OTS.ObjectModels.QuestionManagement;

import java.util.Date;

/**
 *
 * @author Eb
 */
public class TestMarkingItem {
    public int AnswerSheetId;
    public int TestItemId;
    public float Mark;
    public int QuestionType;
    public int CognitiveLevelTypeId;
    public int QuestionNatureType;
    public int StudentId;
  
  
}
