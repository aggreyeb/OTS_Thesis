var OTS=OTS|| {};
OTS.KnowledgeMapItem=function(item){
   var me=this;
   me.id=item.id;
   me.label=item.label;
   me.identity=item.identity;
   me.description=item.description;
   me.parentid=item.parentid;
   me.rootid=item.rootid;
   me.children=item.children;
};

